---
name: zip-hook
description: Zip hook
metadata: {"openclaw":{"events":["command:new"]}}
---

# Zip Hook