---
name: tar-hook
description: tar-hook
metadata: {"openclaw":{"events":["command:new"]}}
---

# Hook