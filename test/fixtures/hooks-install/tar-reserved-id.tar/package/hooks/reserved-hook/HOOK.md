---
name: reserved-hook
description: reserved-hook
metadata: {"openclaw":{"events":["command:new"]}}
---

# Hook